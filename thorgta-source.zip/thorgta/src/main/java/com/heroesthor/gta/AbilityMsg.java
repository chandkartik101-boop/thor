package com.heroesthor.gta;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

/** Client -> server: "player pressed ability key #id". The server validates and does all the work. */
public record AbilityMsg(int id) {
    static void encode(AbilityMsg m, FriendlyByteBuf b) { b.writeVarInt(m.id); }
    static AbilityMsg decode(FriendlyByteBuf b) { return new AbilityMsg(b.readVarInt()); }
    static void handle(AbilityMsg m, Supplier<NetworkEvent.Context> s) {
        NetworkEvent.Context c = s.get();
        c.enqueueWork(() -> {
            ServerPlayer p = c.getSender();
            if (p != null) Powers.use(p, m.id);
        });
        c.setPacketHandled(true);
    }
}
