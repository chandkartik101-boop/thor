package com.heroesthor.gta;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/** All server-side power logic. Ids: 0 lightning, 1 dash, 2 slam, 3 wind, 4 charge toggle. */
public class Powers {
    static final int[] COOLDOWN_TICKS = {40, 50, 80, 40, 10};
    static final String SLAM_START = "gta_slam_start", CHARGE = "gta_charge";

    static void use(ServerPlayer p, int id) {
        if (id < 0 || id >= COOLDOWN_TICKS.length) return;
        CompoundTag d = p.getPersistentData();
        long now = p.level().getGameTime();
        String cd = "gta_cd" + id;
        if (now < d.getLong(cd)) { p.displayClientMessage(Component.literal("Recharging..."), true); return; }
        d.putLong(cd, now + COOLDOWN_TICKS[id]);
        switch (id) {
            case 0 -> lightningBarrage(p);
            case 1 -> dash(p);
            case 2 -> slamStart(p);
            case 3 -> wind(p);
            case 4 -> {
                boolean on = !d.getBoolean(CHARGE);
                d.putBoolean(CHARGE, on);
                p.displayClientMessage(Component.literal("Thunder Charge " + (on ? "ON" : "OFF")), true);
            }
        }
    }

    // GTA V: call lightning down on whatever you point at, several bolts at once.
    static void lightningBarrage(ServerPlayer p) {
        ServerLevel lv = p.serverLevel();
        HitResult h = p.pick(120, 0f, false);
        if (h.getType() == HitResult.Type.MISS) { p.displayClientMessage(Component.literal("No target"), true); return; }
        Vec3 t = h.getLocation();
        for (int i = 0; i < 6; i++) {
            double ox = i == 0 ? 0 : (lv.random.nextDouble() - 0.5) * 8;
            double oz = i == 0 ? 0 : (lv.random.nextDouble() - 0.5) * 8;
            LightningBolt b = EntityType.LIGHTNING_BOLT.create(lv);
            if (b == null) continue;
            b.moveTo(t.x + ox, t.y, t.z + oz);
            b.setCause(p);
            lv.addFreshEntity(b);
        }
    }

    // Sonic-boom launch in the look direction, damaging whatever is near the start.
    static void dash(ServerPlayer p) {
        ServerLevel lv = p.serverLevel();
        Vec3 look = p.getLookAngle();
        for (LivingEntity e : lv.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(3), x -> x != p))
            e.hurt(p.damageSources().playerAttack(p), 6f);
        p.setDeltaMovement(look.scale(3.2));
        p.hurtMarked = true;
        p.fallDistance = 0;
        lv.sendParticles(ParticleTypes.CLOUD, p.getX(), p.getY() + 1, p.getZ(), 40, 0.6, 0.6, 0.6, 0.15);
        lv.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.getX(), p.getY() + 1, p.getZ(), 30, 0.6, 0.6, 0.6, 0.3);
        lv.playSound(null, p.blockPosition(), SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.PLAYERS, 1f, 1.5f);
    }

    // Hop up if grounded, then dive; the shockwave fires on landing (see onPlayerTick).
    static void slamStart(ServerPlayer p) {
        if (p.onGround()) { p.setDeltaMovement(p.getDeltaMovement().add(0, 1.0, 0)); p.hurtMarked = true; }
        p.getPersistentData().putLong(SLAM_START, p.level().getGameTime());
    }

    // Telekinetic blast: throws everything in a forward cone.
    static void wind(ServerPlayer p) {
        ServerLevel lv = p.serverLevel();
        Vec3 look = p.getLookAngle();
        for (LivingEntity e : lv.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(14), x -> x != p)) {
            Vec3 to = e.position().subtract(p.position());
            double dist = to.length();
            if (dist > 14 || dist < 0.01 || to.normalize().dot(look) < 0.6) continue;
            e.setDeltaMovement(look.x * 3, 0.5 + look.y * 1.5, look.z * 3);
            e.hurtMarked = true;
            e.hurt(p.damageSources().playerAttack(p), 4f);
        }
        for (int i = 1; i <= 12; i++) {
            Vec3 q = p.getEyePosition().add(look.scale(i));
            lv.sendParticles(ParticleTypes.CLOUD, q.x, q.y, q.z, 4, 0.3 + i * 0.05, 0.3 + i * 0.05, 0.3 + i * 0.05, 0.02);
        }
        lv.playSound(null, p.blockPosition(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 1.5f, 0.5f);
    }

    static void shockwave(ServerPlayer p, double r, float dmg) {
        ServerLevel lv = p.serverLevel();
        Vec3 c = p.position();
        for (LivingEntity e : lv.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(r), x -> x != p)) {
            double dist = e.distanceTo(p);
            if (dist > r) continue;
            e.hurt(p.damageSources().playerAttack(p), dmg * (float) (1 - dist / r) + 2f);
            Vec3 dir = e.position().subtract(c).normalize();
            e.setDeltaMovement(dir.x * 1.5, 0.8, dir.z * 1.5);
            e.hurtMarked = true;
        }
        lv.sendParticles(ParticleTypes.EXPLOSION_EMITTER, c.x, c.y, c.z, 1, 0, 0, 0, 0);
        lv.sendParticles(ParticleTypes.ELECTRIC_SPARK, c.x, c.y + 0.5, c.z, 80, r / 2, 0.3, r / 2, 0.2);
        lv.playSound(null, p.blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 1.5f, 0.8f);
    }

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p)) return;
        CompoundTag d = p.getPersistentData();
        long now = p.level().getGameTime();

        long slam = d.getLong(SLAM_START);
        if (slam > 0) {
            p.fallDistance = 0; // slam never hurts you
            if (now - slam > 200) d.remove(SLAM_START);
            else if (!p.onGround() && p.getDeltaMovement().y < 0.2 && now - slam > 4) {
                p.setDeltaMovement(0, -2.5, 0);
                p.hurtMarked = true;
            } else if (p.onGround() && now - slam > 6) {
                d.remove(SLAM_START);
                shockwave(p, 9, 14f);
            }
        }

        if (d.getBoolean(CHARGE) && now % 10 == 0) {
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 40, 1, true, false));
            p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 40, 1, true, false));
            p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 40, 1, true, false));
            ServerLevel lv = p.serverLevel();
            lv.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.getX(), p.getY() + 1, p.getZ(), 6, 0.4, 0.8, 0.4, 0.1);
            // Auto-zap one nearby hostile mob.
            for (Monster m : lv.getEntitiesOfClass(Monster.class, p.getBoundingBox().inflate(8))) {
                m.hurt(p.damageSources().playerAttack(p), 5f);
                lv.sendParticles(ParticleTypes.ELECTRIC_SPARK, m.getX(), m.getY() + 1, m.getZ(), 15, 0.3, 0.5, 0.3, 0.2);
                break;
            }
        }
    }
}
