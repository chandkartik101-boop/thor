package com.heroesthor.gta;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

public class ClientKeys {
    static final String CAT = "key.categories.heroesthor_gta";
    // Z lightning, C dash, K slam, J wind, Y charge toggle. Rebindable in Options > Controls.
    static final KeyMapping[] KEYS = {
        new KeyMapping("key.heroesthor_gta.lightning", GLFW.GLFW_KEY_Z, CAT),
        new KeyMapping("key.heroesthor_gta.dash", GLFW.GLFW_KEY_C, CAT),
        new KeyMapping("key.heroesthor_gta.slam", GLFW.GLFW_KEY_K, CAT),
        new KeyMapping("key.heroesthor_gta.wind", GLFW.GLFW_KEY_J, CAT),
        new KeyMapping("key.heroesthor_gta.charge", GLFW.GLFW_KEY_Y, CAT),
    };

    @Mod.EventBusSubscriber(modid = ThorGta.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static class Register {
        @SubscribeEvent
        public static void keys(RegisterKeyMappingsEvent e) { for (KeyMapping k : KEYS) e.register(k); }
    }

    @Mod.EventBusSubscriber(modid = ThorGta.MODID, value = Dist.CLIENT)
    public static class Tick {
        @SubscribeEvent
        public static void tick(TickEvent.ClientTickEvent e) {
            if (e.phase != TickEvent.Phase.END) return;
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || mc.screen != null) return;
            for (int i = 0; i < KEYS.length; i++)
                while (KEYS[i].consumeClick()) ThorGta.CHANNEL.sendToServer(new AbilityMsg(i));
        }
    }
}
