package com.heroesthor.gta;

import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

@Mod(ThorGta.MODID)
public class ThorGta {
    public static final String MODID = "heroesthor_gta";
    private static final String PROTOCOL = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(MODID, "main"), () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    public ThorGta() {
        CHANNEL.registerMessage(0, AbilityMsg.class, AbilityMsg::encode, AbilityMsg::decode, AbilityMsg::handle);
        MinecraftForge.EVENT_BUS.register(new Powers());
    }
}
